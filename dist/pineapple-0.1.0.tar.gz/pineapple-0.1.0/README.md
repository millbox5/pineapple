# Pineapple

Pineapple is a SQLite database browser and management tool built with Flask.

## Installation

You can install the package using pip:
